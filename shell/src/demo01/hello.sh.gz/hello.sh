
#!/bin/bash
echo "Hello World"

#变量
name='disheng'
# echo ${name}

#覆盖变量

name='disheng09'
echo ${name}
# 字符串

name='disheng'
age='18'

echo "${name} is ${age} now"

echo "name length is ${#name}"

echo ${name:1:4} 

count=5

# while count==5
# do
#   count=count-1
#   echo "数量是${count}"
# done

echo "count ${count}"